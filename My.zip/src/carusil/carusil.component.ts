import { Component } from '@angular/core';

@Component({
  selector: 'practice',
  templateUrl: './carusil.component.html',
  styleUrls: ['./carusil.component.css']
})
export class CarusilComponent {
  title = 'My';
}
