import { Component } from '@angular/core';

@Component({
  selector: 'practice',
  templateUrl: './about.component.html',
  //styleUrls: ['./about.component.css']
})
export class AboutComponent {
  title = 'My';
}
