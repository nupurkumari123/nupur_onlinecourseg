export class Users
{
    name:string
    emailid : string
    createpassword : string
    confirmpassword : string

}