import { Component } from '@angular/core';
import { Users } from "src/registration/registration";

@Component({
  selector: 'practice',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {
  title = 'My';
  user:Users=new Users();
  constructor(){

  }
createUser():void{
  console.log(this.user);


}


}

