import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './../home/home.component';
import { LoginComponent } from './../login/login.component';
import { CourseComponent } from './../course/course.component';
import { AboutComponent } from './../about/about.component';
import {CarusilComponent} from '../carusil/carusil.component';
import {ContactComponent} from '../contact/contact.component';
import { ErrorComponent } from './../error/error.component';
import {RegistrationComponent} from '../registration/registration.component';
const routes: Routes = [

  {path:'home',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'course',component:CourseComponent},
  {path:'about',component:AboutComponent},
  {path:'',component:CarusilComponent},
  {path:'contact',component:ContactComponent},
   {path:'registration',component: RegistrationComponent},
  {path:'**',component: ErrorComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
