export class ILogin
{
    username:string
    pass : string

}