import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class LoginService {

private url : string ="../assets/login.json"
  constructor(private httpclient: HttpClient) {}

getLogin():Observable<any>
{
     return this.httpclient.get(this.url); 
}

}

