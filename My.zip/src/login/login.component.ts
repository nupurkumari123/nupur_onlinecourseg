import { Component } from '@angular/core';
import { LoginService } from "src/login/login.service";
import {ILogin} from './login'
import { NgForm } from "@angular/forms/forms";

@Component({
  selector: 'app-root',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent  {
  title = 'My'

login=new ILogin();

constructor(private service:LoginService){
  
}

save(userform:NgForm){
  console.log(userform.form)

}


  // getLogin(userform:NgForm):void{
    
  //    console.log("login")
  //   console.log(userform.form)
  //   console.log(JSON.stringify(userform.form))

   
  //   this.service.getLogin().subscribe(
  //     data => console.log(data)
    
      
  //   )
  // }
}
