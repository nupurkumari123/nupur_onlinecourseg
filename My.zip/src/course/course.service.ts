import { CourseInterface } from 'src/course/course.interface';
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import {tap, catchError} from 'rxjs/operators';
import { Injectable } from '@angular/core';

@Injectable({
providedIn:'root'

})

export class Course{

    courseUrl = './data/course.json';

    constructor(private httpSer:HttpClient) {
    }


    getCourse():Observable<CourseInterface[]>{
    
        return this.httpSer.get<CourseInterface[]>(this.courseUrl).pipe(
        tap(data => console.log('Courses : '+JSON.stringify(data))),
      
    );
}
}
