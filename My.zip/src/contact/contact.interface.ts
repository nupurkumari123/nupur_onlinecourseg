export class ContactUsData{
    public firstname='';
    public email='';
    public message='';
    
}